// Define your Express application and required modules
require('dotenv').config();
const express = require('express');
const app = express();
const path = require('path');
const port = process.env.PORT || 8000;
const hbs = require('hbs');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const cookieParser= require('cookie-parser');
const auth=require("./middleware/auth");


// Connect to your MongoDB database and require your model
require("./db/conn");
const Register = require("./models/registers");
const { Console } = require('console');

// Define paths for Express config
const static_path = path.join(__dirname, "../public");
const template_path = path.join(__dirname, "../templates/views");
const partials_path = path.join(__dirname, "../templates/partials");
console.log(process.env.SECRET_KEY);

// Middleware to parse JSON and urlencoded request bodies
app.use(express.json());
app.use(cookieParser);
app.use(express.urlencoded({ extended: false }));

// Set up static directory to serve
app.use(express.static(static_path));

// Set up Handlebars as the view engine
app.set("view engine", "hbs");
app.set("views", template_path);
hbs.registerPartials(partials_path);

// Define routes

// GET request for homepage
app.get("/", (req, res) => {
    res.render("index");
});

app.get("/secret",auth, (req,res)=>{    // will visit the middleware auth 
    console.log(`cookie value ${req.cookies.jwt}`);
    res.render("index");
});


app.get("/logout",auth,async(req,res)=> {
    try{
           
            console.log(req.user);
            //req.user.tokens=req.user.tokens.filter((currentElement)=>{
              //  return currentElement.token != req.token
            //}) 
            //logout from all devices

           req.user.tokens=[];
           res.clearCookie("jwt");
           console.log('logged out');
           await req.user.save();
           res.render("login");
      
        }
    catch(error){
        res.status(500).send(error);
    }

});


// GET request for registration form
app.get("/register", (req, res) => {
    res.render("register");
});

app.get("/login",(req,res)=>{
    res.render("login");
})
// POST request to handle form submission from registration form
app.post("/register", async (req, res) => {
    console.log("POST /register endpoint hit");
    console.log("Request body:", req.body);

    try {
        const { password, confirmpassword } = req.body;
        
        // Check if passwords match
        if (password !== confirmpassword) {
            return res.status(400).send("Passwords do not match");
        }
        else {

        // Create a new instance of Register model
        const registerEmployee = new Register({
            Fullname: req.body.Fullname,
            Username: req.body.Username,
            Email: req.body.Email,
            PhoneNumber: req.body.PhoneNumber,
            Password: req.body.password,
            confirmpassword: req.body.confirmpassword
        });

            console.log("the success part"+ registerEmployee);
        const token=  await registerEmployee.generateAuthToken();
        console.log("the token part"+token);

            //set the cookie
            res.cookie("jwt",token);
            console.log(`this is cookie ${req.cookies.jwt}`); //jwt is cookie name;





        // Save the new user to the database
        const registered = await registerEmployee.save();
        console.log("token part"+token);
        console.log("Registration successful");
        res.status(201).render("index"); // Render a success page or redirect as needed
    }
    } catch (error) {
       res.status(400).send(error);
       console.log("the error part page");
    }
});




//login check 
app.post("/login", async(req,res)=>{

try{
    const Email=req.body.Email;
    const Password=req.body.Password;

    const useremail= await Register.findOne({Email:Email});
    const isMatch= await bcrypt.compare(Password,useremail.Password);    
    const token=  await useremail.generateAuthToken();
    
    console.log("the token part"+token);
    res.cookie("jwt",token, {
        httpOnly:true,
    });
    
    if(!isMatch){
        res.send("password not matching");
    }
    else{
        res.status(201).render("index");
    }
}
catch{
    res.status(400).send("Invalid Email");
}
})











// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
