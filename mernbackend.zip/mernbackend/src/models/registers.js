const mongoose=require("mongoose");
const bcrypt= require("bcryptjs");
const jwt=require('jsonwebtoken');

const employeeSchema= new mongoose.Schema({
    Fullname:{
        type: String,
        required:true
    },

    Username:{
        type:String,
        required:true
    },
    Email:{
        type:String,
        required:true
    },
    PhoneNumber:{
        type:Number,
        required:true
    },
    Password:{
        type:String,
        required:true

    },
    confirmpassword:{
        type:String,
        required:true
    },
    tokens:[
        {
            token:{
                type:String,
        required:true
            }
        }
    ]

    
})

employeeSchema.methods.generateAuthToken =async function(){
    try{
        console.log(this._id);
        const token= jwt.sign({_id:this._id.toString()},process.env.SECRET_KEY);
        this.tokens=this.tokens.concat({token:token});
        await this.save();

    }
    catch(error){
            res.send("the error part"+error);
    }
}

employeeSchema.pre("save", async function(next){
    if(this.isModified("Password")){

    
    //const passwordHash= await bcrypt.hash(Password,10);
    console.log(`${this.Password}`);
    
    this.Password=await bcrypt.hash(this.Password,10);
    this. confirmpassword=await bcrypt.hash(this.confirmpassword,10);
  
    }

    next();
})
// we need to create a collecition.

const Register = new mongoose.model("Register",employeeSchema);
module.exports= Register;